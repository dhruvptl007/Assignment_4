const apiKey = '9e9e7c99d40b14452176aa3e7f1df322';

async function getWeatherData(city) {
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
    
    const response = await fetch(apiUrl); 
    const data = await response.json();
    return data;
}

async function displayWeather(city) {
    const weatherInfo = document.getElementById('weather-info');
    
    try {
        const data = await getWeatherData(city);
        const description = data.weather[0].description;
        const temperature = data.main.temp;
        const weatherIcon = data.weather[0].icon;
        
        const weatherDataHTML = `
            <h2>Weather in ${city}</h2>
            <img class="weather-icon" src="http://openweathermap.org/img/w/${weatherIcon}.png" alt="Weather Icon">
            <p>Description: ${description}</p>
            <p>Temperature: ${temperature}°C</p>
        `;

        const weatherDataElement = document.createElement('div');
        weatherDataElement.className = 'weather-data';
        weatherDataElement.innerHTML = weatherDataHTML;

        weatherInfo.appendChild(weatherDataElement);
    } catch (error) {
        weatherInfo.innerHTML = 'Error fetching weather data.';
        console.error(error);
    }
}


const searchButton = document.getElementById('search-button');
searchButton.addEventListener('click', () => {
    const cityInput = document.getElementById('city-name');
    const city = cityInput.value;
    if (city.trim() !== '') {
        displayWeather(city);
        cityInput.value = '';
    }
});


const refreshButton = document.getElementById('refresh-button');
refreshButton.addEventListener('click', () => {
    const weatherInfo = document.getElementById('weather-info');
    weatherInfo.innerHTML = ''; 
    cities.forEach(city => {
        displayWeather(city);
    });
});

const cities = ['Toronto', 'Barrie'];


cities.forEach(city => {
    displayWeather(city);
});
